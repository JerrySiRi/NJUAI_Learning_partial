#include <iostream>
using namespace std;
struct Car//�ṹ���͵Ķ��� 
{
	bool da;
	bool xiao;
} ;

int free(char arr[],Car zaibuzai[]); 
bool weekend(char arr[]);
