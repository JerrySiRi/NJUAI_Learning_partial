#ifndef __TIMER_H__
#define __TIMER_H__

void initTimer();

#endif
