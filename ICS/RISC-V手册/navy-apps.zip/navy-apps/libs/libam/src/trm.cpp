#include <am.h>

Area heap;

void putch(char ch) {
}

void halt(int code) {
}
