#ifndef __AM_H__
#define __AM_H__

#define ARCH_H "navy.h"
#include "am-origin.h"

#endif
