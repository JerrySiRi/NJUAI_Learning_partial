SDL-based flappy bird clone.
